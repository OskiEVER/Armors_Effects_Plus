package com.armors_plus;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3481;
import net.minecraft.class_3730;
import net.minecraft.class_5134;
import net.minecraft.class_8111;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Random;

public class Aromors implements ModInitializer {
    
    public static final String MOD_ID = "aromors";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static final class_2960 NETHERITE_KB_ID = class_2960.method_60655(MOD_ID, "netherite_knockback_boost");
    private static final Random RANDOM = new Random();

    @Override
    public void onInitialize() {
        // Pętla serwera obsługująca efekty stałe zbroi
        ServerTickEvents.START_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                checkArmorEffects(player);
            }
        });

        // Obsługa szansy na piorun przy uderzeniu moba w miedzianej zbroi (5% na 1, 1% na 3)
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!world.method_8608() && entity instanceof class_1309 target && player instanceof class_3222 serverPlayer) {
                if (hasFullSet(serverPlayer, class_1802.field_61343, class_1802.field_61344, class_1802.field_61345, class_1802.field_61346)) {
                    int roll = RANDOM.nextInt(100); // Losowanie 0 - 99

                    if (roll < 1) { // 1% szansy na 3 pioruny
                        spawnLightning(world, target.method_24515());
                        spawnLightning(world, target.method_24515());
                        spawnLightning(world, target.method_24515());
                    } else if (roll < 6) { // 5% szansy na 1 piorun
                        spawnLightning(world, target.method_24515());
                    }
                }
            }
            return class_1269.field_5811;
        });

        // Odporność na obrażenia od piorunów w miedzianej zbroi
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof class_3222 player) {
                if (hasFullSet(player, class_1802.field_61343, class_1802.field_61344, class_1802.field_61345, class_1802.field_61346)) {
                    if (source.method_49708(class_8111.field_42336)) {
                        return false; // Anuluje obrażenia od pioruna w 100%
                    }
                }
            }
            return true;
        });

        LOGGER.info("Aromors+ odpala się z miedzianymi piorunami!");
    }

    private void spawnLightning(net.minecraft.class_1937 world, class_2338 pos) {
        if (world instanceof class_3218 serverWorld) {
            class_1299.field_6112.method_47821(serverWorld, pos, class_3730.field_16461);
        }
    }

    private void checkArmorEffects(class_3222 player) {
        class_3218 world = (class_3218) player.method_51469();

        // a) Skórzana zbroja - Usuwa truciznę
        if (hasFullSet(player, class_1802.field_8267, class_1802.field_8577, class_1802.field_8570, class_1802.field_8370)) {
            if (player.method_6059(class_1294.field_5899)) {
                player.method_6016(class_1294.field_5899);
            }
        }

        // c) Kolczuga - Obrażenia z bliska (1 serce na sekundę)
        if (hasFullSet(player, class_1802.field_8283, class_1802.field_8873, class_1802.field_8218, class_1802.field_8313)) {
            if (player.field_6012 % 20 == 0) { 
                class_238 box = player.method_5829().method_1014(0.5); 
                for (class_1309 entity : world.method_8390(class_1309.class, box, e -> e != player)) {
                    entity.method_64397(world, player.method_48923().method_48818(player), 2.0f); 
                }
            }
        }

        // d) Żelazna zbroja - Siła i lekkie spowolnienie
        if (hasFullSet(player, class_1802.field_8743, class_1802.field_8523, class_1802.field_8396, class_1802.field_8660)) {
            player.method_6092(new class_1293(class_1294.field_5910, 40, 0, false, false, true));
            player.method_6092(new class_1293(class_1294.field_5909, 40, 0, false, false, true));
        }

        // e) Diamentowa zbroja - Szybkość i radar rud (promień 3 kratki)
        if (hasFullSet(player, class_1802.field_8805, class_1802.field_8058, class_1802.field_8348, class_1802.field_8285)) {
            player.method_6092(new class_1293(class_1294.field_5904, 40, 1, false, false, true)); 
            
            if (player.field_6012 % 25 == 0) { 
                class_2338 playerPos = player.method_24515();
                int radius = 3;
                class_2338 closestOre = null;
                double minDistanceSq = Double.MAX_VALUE;
                
                for (int x = -radius; x <= radius; x++) {
                    for (int y = -radius; y <= radius; y++) {
                        for (int z = -radius; z <= radius; z++) {
                            class_2338 checkPos = playerPos.method_10069(x, y, z);
                            if (world.method_8320(checkPos).method_26164(class_3481.field_28989) || 
                                world.method_8320(checkPos).method_26164(class_3481.field_23062) ||
                                world.method_8320(checkPos).method_26164(class_3481.field_28988) ||
                                world.method_8320(checkPos).method_26164(class_3481.field_29193) ||
                                world.method_8320(checkPos).method_26164(class_3481.field_29195) ||
                                world.method_8320(checkPos).method_26164(class_3481.field_28990) ||
                                world.method_8320(checkPos).method_26164(class_3481.field_28991) ||
                                world.method_8320(checkPos).method_26164(class_3481.field_29194) ||
                                world.method_8320(checkPos).method_27852(class_2246.field_22109)) {
                                
                                double distSq = playerPos.method_10262(checkPos);
                                if (distSq < minDistanceSq) {
                                    minDistanceSq = distSq;
                                    closestOre = checkPos;
                                }
                            }
                        }
                    }
                }
                
                if (closestOre != null) {
                    class_2561 message = class_2561.method_43469(
                        "text.aromors.ore_radar", 
                        closestOre.method_10263(), closestOre.method_10264(), closestOre.method_10260()
                    );
                    
                    player.method_7353(message, true);
                    world.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), 
                        net.minecraft.class_3417.field_14725.comp_349(), 
                        net.minecraft.class_3419.field_15248, 0.6f, 1.2f);
                }
            }
        }

        // f) Netherytowa zbroja - Odporność na ogień i 100% odporności na odrzut
        boolean hasNetherite = hasFullSet(player, class_1802.field_22027, class_1802.field_22028, class_1802.field_22029, class_1802.field_22030);
        if (hasNetherite) {
            player.method_6092(new class_1293(class_1294.field_5918, 40, 0, false, false, true));
            
            class_1324 kbAttr = player.method_5996(class_5134.field_23718);
            if (kbAttr != null && !kbAttr.method_6196(NETHERITE_KB_ID)) {
                kbAttr.method_26835(new class_1322(NETHERITE_KB_ID, 0.6, class_1322.class_1323.field_6328));
            }
        } else {
            class_1324 kbAttr = player.method_5996(class_5134.field_23718);
            if (kbAttr != null && kbAttr.method_6196(NETHERITE_KB_ID)) {
                kbAttr.method_6200(NETHERITE_KB_ID);
            }
        }

        // g) Czapka żółwia - Oddychanie pod wodą
        if (player.method_6118(class_1304.field_6169).method_31574(class_1802.field_8090)) {
            player.method_6092(new class_1293(class_1294.field_5923, 40, 0, false, false, true));
        }
    }

    private boolean hasFullSet(class_3222 player, class_1792 helmet, class_1792 chestplate, class_1792 leggings, class_1792 boots) {
        return player.method_6118(class_1304.field_6169).method_31574(helmet) &&
               player.method_6118(class_1304.field_6174).method_31574(chestplate) &&
               player.method_6118(class_1304.field_6172).method_31574(leggings) &&
               player.method_6118(class_1304.field_6166).method_31574(boots);
    }
}