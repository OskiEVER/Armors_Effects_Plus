package com.armors_plus.mixin;

import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1309.class)
public class LivingEntityMixin {
    @ModifyVariable(method = "handleFallDamage", at = @At("HEAD"), ordinal = 0, argsOnly = true)
    private float aromors_increaseFallDamage(float fallDistance) {
        class_1309 entity = (class_1309) (Object) this;
        if (entity instanceof class_3222 player) {
            if (player.method_6118(class_1304.field_6169).method_31574(class_1802.field_8862) &&
                player.method_6118(class_1304.field_6174).method_31574(class_1802.field_8678) &&
                player.method_6118(class_1304.field_6172).method_31574(class_1802.field_8416) &&
                player.method_6118(class_1304.field_6166).method_31574(class_1802.field_8753)) {
                return fallDistance * 2.0f; 
            }
        }
        return fallDistance;
    }
}