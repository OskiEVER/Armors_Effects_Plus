package com.armors_plus.mixin;

import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4836;
import net.minecraft.class_4838;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4838.class)
public class PiglinBrainMixin {
    @Inject(method = "onAttacked", at = @At("HEAD"), cancellable = true)
    private static void aromors_cancelPiglinAggro(class_3218 world, class_4836 piglin, class_1309 attacker, CallbackInfo ci) {
        if (attacker instanceof class_3222 player) {
            if (player.method_6118(class_1304.field_6169).method_31574(class_1802.field_8862) &&
                player.method_6118(class_1304.field_6174).method_31574(class_1802.field_8678) &&
                player.method_6118(class_1304.field_6172).method_31574(class_1802.field_8416) &&
                player.method_6118(class_1304.field_6166).method_31574(class_1802.field_8753)) {
                ci.cancel();
            }
        }
    }
}